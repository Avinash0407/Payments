DROP TABLE Customer IF EXISTS;

CREATE TABLE Customer  (
    id VARCHAR(20),
    name VARCHAR(20)
);
